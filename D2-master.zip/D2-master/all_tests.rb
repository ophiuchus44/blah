require 'simplecov'
SimpleCov.start

require 'minitest/autorun'
require './valid_args?'
require './game'
require './valid_args_test.rb'
require './game_test.rb'
