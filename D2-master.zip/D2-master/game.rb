# This is a shiny game
class Game
  attr_accessor :gold, :silver, :current_city, :day, :random_number, :city_number, :cities

  def initialize(seed, num_prospectors)
    @rng = seed.to_i
    srand(@rng)
    @num_prospectors = num_prospectors.to_i

    @gold = 0
    @silver = 0
    @day = 1
    @prospector_id = 1

    @cities = {
      'Sutter Creek' => { 'name' => 'Sutter Creek', 'next_cities' => ['Coloma', 'Angels Camp'],
                          'gold_max' => 2, 'silver_max' => 0 },
      'Angels Camp' => { 'name' => 'Angels Camp', 'next_cities' => ['Nevada City', 'Virginia City', 'Sutter Creek'],
                         'gold_max' => 4, 'silver_max' => 0 },
      'Nevada City' => { 'name' => 'Nevada City', 'next_cities' => ['Angels Camp'], 'gold_max' => 5,
                         'silver_max' => 0 },
      'Virginia City' => { 'name' => 'Virginia City', 'next_cities' => ['Angels Camp', 'Coloma', 'Midas'],
                           'gold_max' => 3, 'silver_max' => 3 },
      'Coloma' => { 'name' => 'Coloma', 'next_cities' => ['Sutter Creek', 'Virginia City'],
                    'gold_max' => 3, 'silver_max' => 0 },
      'Midas' => { 'name' => 'Midas', 'next_cities' => ['Virginia City', 'El Dorado Canyon'],
                   'gold_max' => 0, 'silver_max' => 5 },
      'El Dorado Canyon' => { 'name' => 'El Dorado Canyon', 'next_cities' => ['Virginia City', 'Midas'],
                              'gold_max' => 0, 'silver_max' => 10 }
    }

    @current_city = @cities['Sutter Creek']

    @random_number = make_rand
  end

  def mine(gold_min, silver_min)
    mined_gold, mined_silver = 99

    until mined_gold < gold_min && mined_silver < silver_min
      break if gold_min < 1 && silver_min < 1

      @day += 1
      mined_gold = rand(@current_city['gold_max'])
      mined_silver = rand(@current_city['silver_max'])

      puts print_found(mined_gold, mined_silver, @current_city['name'])

      @gold += mined_gold unless mined_gold < 1
      @silver += mined_silver unless mined_silver < 1
    end

    gold_min >= 1 && silver_min >= 1 ? [mined_gold, mined_silver] : 'Your standards are too low!'
  end

  def print_found(gold, silver, city)
    if gold >= 1 && silver >= 1
      "	Found #{gold} #{ounces? gold} of gold and #{silver} #{ounces? silver} of silver in #{city}."
    elsif gold >= 1
      "	Found #{gold} #{ounces? gold} of gold in #{city}."
    elsif silver >= 1
      "	Found #{silver} #{ounces? silver} of silver in #{city}."
    else
      "	Found no precious metals in #{city}."
    end
  end

  def calculate_loot
    gold_value = @gold * 20.67
    silver_value = @silver * 1.31
    total_value = gold_value + silver_value

    printf "After #{@day} days, Prospector #{@prospector_id} returned to #{@current_city['name']} with:
        #{@gold} #{ounces? @gold} of gold\n	#{@silver} #{ounces? @silver} of silver
	Heading home with $#{format('%.2f', total_value)}.\n"

    [gold_value.round(2), silver_value.round(2)]
  end

  def ounces?(ounces)
    ounces == 1 ? 'ounce' : 'ounces'
  end

  def make_rand
    rand(0..100)
  end

  def play
    while @prospector_id <= @num_prospectors

      @city_number = 1

      # Need to always start on Sutter Creek
      puts "\nProspector #{@prospector_id} starting in Sutter Creek."
      mine(1, 1)

      # Simulate trip
      while @city_number < 5

        # keep local dictionary of last city
        last_city = @current_city

        # get the next city and set it to current
        @current_city = @cities[@current_city['next_cities'].sample]

        print "Heading from #{last_city['name']} to #{@current_city['name']}, "
        puts "holding #{@gold} #{ounces? @gold} of gold and #{@silver} #{ounces? @silver} of silver."

        if @city_number < 3
          mine(1, 1)
        else
          mine(2, 3)
        end

        @city_number += 1
      end

      # Print loot
      calculate_loot

      # Reset variables
      @gold = 0
      @silver = 0

      @day = 1

      @prospector_id += 1

    end
  end
end
