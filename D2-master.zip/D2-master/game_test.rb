require 'minitest'
# UNIT TESTS FOR GAME CLASS
class GameTest < Minitest::Test
  # UNIT TESTS FOR METHOD mine(gold_min, silver_min)
  # Equivalence classes:
  # gold_min = 1..INFINITY -> returns a random amount of gold until minimum not met
  # silver_min = 1..INFINITY -> returns a random amount of gold until minimum not met
  # gold_min = 0 XOR silver_min = 0 -> returns a random amount of the nonzero metal until minimum not met
  # gold_min = -INFINITY..0 && silver_min = -INFINITY..0 -> returns error message

  # If a prospector leaves one of the first three cities, they found no gold that day.
  def test_first3_gold_not_found
    game = Game.new 10, 1
    last_mined = game.mine(1, 1)

    assert last_mined[0] < 1
  end

  # If a prospector leaves one of the first three cities, they found no silver that day.
  def test_first3_silver_not_found
    game = Game.new 10, 1

    last_mined = game.mine(1, 1)
    assert last_mined[1] < 1
  end

  # If a prospector leaves one of the last two cities,
  # they failed to find more than 1 ounce of gold or 2 ounces of silver.
  def test_last2_gold_silver_leave
    game = Game.new 10, 1
    last_mined = game.mine(2, 3)

    assert last_mined[0] < 2 && last_mined[1] < 3
  end

  # If gold_min and silver_min are too low, return an error message.
  # EDGE CASE
  def test_minimum_metals_valid
    game = Game.new 10, 1
    last_mined = game.mine(0, 0)

    assert_equal last_mined, 'Your standards are too low!'
  end

  # UNIT TESTS FOR METHOD calculate_loot
  # Equivalence classes:
  # @gold >= 1 -> returns @gold * 20.67
  # @silver >= 1 -> returns @silver * 1.31

  # If gold and silver are nonzero values, then a scalar multiple of the corresponding metal value is returned.
  def test_calculate_loot_gold
    game = Game.new 10, 1
    game.gold = 3
    game.silver = 5
    tmp = game.calculate_loot
    gold = tmp[0]
    silver = tmp[1]

    assert_equal 62.01, gold
    assert_equal 6.55, silver
  end

  # If the sum produced has a cent value divisible by 10, check that the trailing 0 is retained.
  # EDGE CASE
  def test_print_two_decimals
    game = Game.new 10, 1
    game.gold = 3
    game.silver = 9
    assert_equal 73.80, game.calculate_loot.sum
  end

  # UNIT TESTS FOR METHOD print_found(gold, silver, city)
  # Equivalence classes:
  # gold >= 1 && silver >= 1 -> Print both metal values
  # gold >= 1 && silver < 1 -> Print gold value only
  # gold < 1 && silver >= 1 -> Print silver value only
  # gold < 1 && silver < 1 -> Print no metals found message

  # If gold and silver both equal 0, state that no precious metals were found.
  def test_print_found_no_gold_or_silver
    game = Game.new 10, 1
    tmp = game.print_found(0, 0, 'Sutter Creek')
    assert_equal "\tFound no precious metals in Sutter Creek.", tmp
  end

  # If gold = 1 and silver = 0, only print a non-plural gold found message.
  def test_print_found_just_gold_single
    game = Game.new 10, 1
    tmp = game.print_found(1, 0, 'Sutter Creek')
    assert_equal "\tFound 1 ounce of gold in Sutter Creek.", tmp
  end

  # If gold = 0 and silver = 1, only print a non-plural silver found message.
  def test_print_found_just_silver_single
    game = Game.new 10, 1
    tmp = game.print_found(0, 1, 'Sutter Creek')
    assert_equal "\tFound 1 ounce of silver in Sutter Creek.", tmp
  end

  # If gold > 1 and silver = 0, only print a plural gold found message.
  def test_print_found_just_gold_plural
    game = Game.new 10, 1
    tmp = game.print_found(3, 0, 'Sutter Creek')
    assert_equal "\tFound 3 ounces of gold in Sutter Creek.", tmp
  end

  # If gold = 0 and silver > 1, only print a plural silver found message.
  def test_print_found_just_silver_plural
    game = Game.new 10, 1
    tmp = game.print_found(0, 3, 'Sutter Creek')
    assert_equal "\tFound 3 ounces of silver in Sutter Creek.", tmp
  end

  # If gold > 1 and silver > 1, print a plural found message for both metals.
  def test_print_found_gold_silver_plural
    game = Game.new 10, 1
    tmp = game.print_found(3, 3, 'Sutter Creek')
    assert_equal "\tFound 3 ounces of gold and 3 ounces of silver in Sutter Creek.", tmp
  end

  def test_cities_name
    game = Game.new 10, 1
    tmp = game.cities['Angels Camp']['name']
    assert_equal 'Angels Camp', tmp
  end

  # UNIT TESTS FOR METHOD ounces?(ounces)
  # Equivalence classes:
  # ounces = 1 -> Return 'ounce'
  # ounces != 1 -> Return 'ounces'

  # If ounces are equal to 1, return the singular form of ounce.
  def test_ounce_single
    game = Game.new 10, 1
    assert_equal 'ounce', game.ounces?(1)
  end

  # If ounces are greater than 1, return the plural form of ounces
  def test_ounces_plural_greaterthan1
    game = Game.new 10, 1
    assert_equal 'ounces', game.ounces?(2)
  end

  # If ounces are equal to 0, return the plural form of ounces
  # EDGE CASE
  def test_ounces_plural_zero
    game = Game.new 10, 1
    assert_equal 'ounces', game.ounces?(0)
  end

  # If a game is initialized, the starting location will be Sutter Creek.
  def test_start_sutter_creek
    game = Game.new 10, 1
    assert_equal 'Sutter Creek', game.current_city['name']
  end

  # UNIT TEST FOR METHOD play

  # Once a game is played, each prospector will visit exactly 5 locations.
  def test_number_of_city_visits
    game = Game.new 10, 3
    game.play
    assert_equal 5, game.city_number
  end

  # When a game is initialized with the same seed, the outputs will be equal.
  def test_seed_match
    g1 = start_game 10, 1
    g2 = start_game 10, 1

    assert_equal g1.random_number, g2.random_number
  end

  # Helper method for test_seed_match.
  def start_game(seed, num_prospectors)
    Game.new seed, num_prospectors
  end
end
