require './valid_args?'
require './game'

seed = ARGV[0]
num_prospectors = ARGV[1]

if valid_args?(seed, num_prospectors)

  game = Game.new(seed, num_prospectors)
  game.play

else

  exit 1

end
