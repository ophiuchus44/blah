# Encoding: UTF-8

require "gosu"

module ZOrder
  BACKGROUND, STARS, PLAYER, UI = *0..3
end

class Player
  attr_reader :score, :gold_score, :silver_score, :day, :time, :startTime
  
  def initialize
    @image = Gosu::Image.new("starfighter.bmp")
    @x = @y = @vel_x = @vel_y = @angle = 0.0
    @score = 0
    @gold_score =0
    @silver_score = 0
    @day = 0
    @time = 5
    @startTime = Time.now

  end

  def warp(x, y)
    @x, @y = x, y
  end
  
  def turn_left
    @angle -= 4.5
  end
  
  def turn_right
    @angle += 4.5
  end
  
  def accelerate
    @vel_x += Gosu.offset_x(@angle, 0.5)
    @vel_y += Gosu.offset_y(@angle, 0.5)
  end
  
  def move
    @x += @vel_x
    @y += @vel_y
    @x %= 640
    @y %= 480
    
    @vel_x *= 0.70
    @vel_y *= 0.70
  end
  
  def draw
    @image.draw_rot(@x, @y, ZOrder::PLAYER, @angle)
  end

  def gameover
      # this method is a checker because sometimes the timer resets to 60
      if Time.now- @startTime  >5
        gold = @gold_score* 20.67
        silver = @silver_score* 1.31
        total_value = gold + silver

        puts "************** GAME OVER **************"
        puts "Sorry, you did not find the next gold or silver in time!"
        puts "\tYou found #{@gold_score} #{ounces? @gold_score} of gold which is worth $#{gold.round(2)}"
        puts "\tYou found #{@silver_score} #{ounces? @silver_score} of silver which is worth $#{silver.round(2)}"
        puts "\tHeading home with $#{tota_value.round(2)}"
        puts "***************************************"
        exit
      elsif @startTime - Time.now < 5
        @startTime = Time.now
        return 0
      end
  end


  def ounces?(ounces)
    ounces == 1 ? 'ounce' : 'ounces'
  end
  
  def collect_stars(stars)

    stars.reject! do |star|
      if Gosu.distance(@x, @y, star.x, star.y) < 35 && gameover == 0
        @day += 1
        if star.type == "gold"
          @gold_score += 1
        elsif star.type == "silver"
          @silver_score += 1
        end

        @startTime = Time.now # reset timer
        
        true
      else
        false
      end
    end
  end
end

class Silver_Star
  attr_reader :x, :y, :type
  
  def initialize(animation)
    @animation = animation
    @color = Gosu::Color::GRAY
    @type = "silver"
    @x = rand * 640
    @y = rand * 480
  end
  
  def draw
    img = @animation[Gosu.milliseconds / 100 % @animation.size]
    img.draw(@x - img.width / 2.0, @y - img.height / 2.0,
        ZOrder::STARS, 1, 1, @color, :add)
  end
end


class Gold_Star
  attr_reader :x, :y, :type
  
  def initialize(animation)
    @animation = animation
    @color = Gosu::Color::YELLOW
    @type = "gold"
    @x = rand * 640
    @y = rand * 480
  end
  
  def draw
    img = @animation[Gosu.milliseconds / 100 % @animation.size]
    img.draw(@x - img.width / 2.0, @y - img.height / 2.0,
        ZOrder::STARS, 1, 1, @color, :add)
  end
end

class Tutorial < (Example rescue Gosu::Window)
  
  def initialize
    super 640, 480
    self.caption = "$$$ GOLD RUSH! (and also silver?) $$$ "
    
    @background_image = Gosu::Image.new("space.png", tileable: true)
    
    @player = Player.new
    @player.warp(320, 240)
    
    @star_anim = Gosu::Image::load_tiles("star.png", 25, 25)
    @stars = Array.new
    
    @font = Gosu::Font.new(20)
    @font2 = Gosu::Font.new(30)

  end



  
  def update
    if Gosu.button_down? Gosu::KB_LEFT or Gosu.button_down? Gosu::GP_LEFT
      @player.turn_left
    end
    if Gosu.button_down? Gosu::KB_RIGHT or Gosu.button_down? Gosu::GP_RIGHT
      @player.turn_right
    end
    if Gosu.button_down? Gosu::KB_UP or Gosu.button_down? Gosu::GP_BUTTON_0
      @player.accelerate
    end
    @player.move
    @player.collect_stars(@stars)

    
    if rand(100) < 4 and @stars.size < 5
      @stars.push(Gold_Star.new(@star_anim))
    end

    if rand(100) < 4 and @stars.size < 5
      @stars.push(Silver_Star.new(@star_anim))
    end


  end
  
  def draw

    time_now = Time.now.strftime("%S").to_i
    time_start = @player.startTime.strftime("%S").to_i
    time_diff = 5 - (time_now - time_start)
    
    #exit 
    if time_diff <= 0
      
        gold = @player.gold_score* 20.67
        silver = @player.silver_score* 1.31
        total_value = gold + silver

        puts "************** GAME OVER **************"
        puts "Sorry, you did not find the next gold or silver in time!"
        puts "\tYou found #{@player.gold_score} #{ounces? @player.gold_score} of gold which is worth $#{gold.round(2)}"
        puts "\tYou found #{@player.silver_score} #{ounces? @player.silver_score} of silver which is worth $#{silver.round(2)}"
        puts "\tHeading home with $#{total_value.round(2)}"
        puts "***************************************"
      exit
      end 


    @background_image.draw(0, 0, ZOrder::BACKGROUND)
    @player.draw
    @stars.each { |star| star.draw }
    @font.draw("Prospect: #1", 10, 10, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("Gold: #{@player.gold_score} #{ounces? @player.gold_score} ", 10, 30, ZOrder::UI, 1.0, 1.0, Gosu::Color::YELLOW)
    @font.draw("Silver: #{@player.silver_score} #{ounces? @player.silver_score}", 10, 50, ZOrder::UI, 1.0, 1.0, Gosu::Color::GRAY)
    @font.draw("Day: #{@player.day}", 300, 10, ZOrder::UI, 1.0, 1.0, Gosu::Color::YELLOW)

    
    # @font2.draw("TIME LEFT: #{Time.now.strftime("%S")} - #{@player.startTime.strftime("%S")}", 250, 30, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)

    @font2.draw("TIME LEFT: #{time_diff}", 250, 30, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)


    # city locations
    @font.draw("Nevada City", 10, 110, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("Angels Camp", 65, 200, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("Sutter Creek", 30, 400, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("Virginia City", 280, 220, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("Midas", 440, 140, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("El Dorado Canyon", 440, 280, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)
    @font.draw("Coloma", 280, 400, ZOrder::UI, 1.0, 1.0, Gosu::Color::WHITE)

  end


   def ounces?(ounces)
    ounces == 1 ? 'ounce' : 'ounces'
  end
  
  def button_down(id)
    if id == Gosu::KB_ESCAPE
      close
    else
      super
    end
  end
end

Tutorial.new.show if __FILE__ == $0
