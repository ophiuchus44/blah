def valid_args?(arg1, arg2)
  if arg1.to_i != 0 && arg2.to_i != 0 && arg2.to_i >= 1
    1
  else
    print "Usage:\nruby gold_rush.rb *seed* *num_prospectors*\n*seed* should be an integer\n"
    puts '*num_prospectors* should be a non-negative integer'

    0
  end
end
