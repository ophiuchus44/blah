# This class tests the command line arguments
class ArgumentTest < Minitest::Test
  # UNIT TESTS FOR METHOD valid_args?(seed, num_prospectors)
  # Equivalence classes:
  # seed = -INFINITY..INFINITY && num_prospectors = 1..INFINITY -> returns 1
  # seed != INTEGER || num_prospectors != INTEGER || num_prospectors = -INFINITY..0 -> returns 0

  # If two unsigned integers are given for seed and num_prospectors, then 1 is returned
  def test_arguments_valid
    assert_equal 1, valid_args?(10, 10)
  end

  # If an invalid value, such as a string, is given for seed or num_prospectors, then 1 is returned.
  def test_arguments_invalid
    assert_equal 0, valid_args?(10, 'Sapphire')
    assert_equal 0, valid_args?('Emerald', 10)
  end

  # If a negative value is passed for num_prospectors, then 0 is returned
  def test_arguments_negative
    assert_equal 0, valid_args?(10, -99)
  end
end
